var d;
var time;

const admin = require('firebase-admin');
const serviceAccount = require('./serverPrivateKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://gizmolife-cloud-android.firebaseio.com/'

});

var redis = require('redis');
var redisClient = redis.createClient('6379', '172.26.4.161');

redisClient.subscribe('FCMNotifications_for_ios_mwc');
console.log("FCM key has been subscribed");

redisClient.on('message', function(channel, message) {
	//time = d.getTime();
	d = new Date();
	console.log(d + ": New message in queue "+ message + "\n\n");
	var msg = JSON.parse(message);
	registration_id = msg.registration_ids;
	delete msg.registration_ids;
	//console.log(msg.data);

	var Data = {
		payload : msg.data.payload,
		priority : msg.data.priority
	}

	if(msg.data.title == "" || msg.data.message == ""){
		if(msg.data.hasOwnProperty('image') && msg.data.hasOwnProperty('notId')){
			var message = {
				notification: {
					title : msg.data.title,
					body : msg.data.message,
					// sound: "silence.wav",
					id : JSON.stringify(msg.data.notId),
					notificationId: JSON.stringify(msg.data.notId),	
					additionalData : JSON.stringify(Data),
					priority: "high",
					//"mutable-content": "1",
					// badge: "1"
					//icon: msg.data.image,
					//"content-available": "1",
					"content_available": "true"//,
					//"mutable_content" : "1"
				},
			    data: {
			    	title : msg.data.title,
			    	body : msg.data.message,
					additionalData : JSON.stringify(Data),
					id : JSON.stringify(msg.data.notId),
					//sound: msg.data.soundname,
					image : msg.data.image,
					//"mutable-content": "1",
					//priority: "high",
					// badge: "1"
					notificationId : JSON.stringify(msg.data.notId),
					//"content-available": "1",
					"content_available": "true"//,
					//"mutable_content" : "1"
				}
			};
		}else{
			var message = {
				notification: {
					title : msg.data.title,
					body : msg.data.message,
					// sound: "silence.wav",
					//icon: "notification_big",
					additionalData : JSON.stringify(Data),
					//"mutable-content": "1",
					priority: "high",
					// badge: "1",
					//"content-available": "1",
					"content_available": "true"//,
					//"mutable_content" : "1"
				},
			    data: {
			    	title : msg.data.title,
			    	body : msg.data.message,
					additionalData : JSON.stringify(Data),
					//"mutable-content": "1",
					//priority: "high",
					//"content-available": "1",
					"content_available": "true"//,
					// badge: "1"//,
					//"mutable_content" : "1"
					//sound: msg.data.soundname
				}
			};
		}
	}else if(msg.data.hasOwnProperty('picture')){
		var message = {
			notification: {
		    	title : msg.data.title,
				body : msg.data.message,
				icon : msg.data.image,	
				id : JSON.stringify(msg.data.notId),
				notificationId: JSON.stringify(msg.data.notId),			
				sound: msg.data.soundname,
				style: msg.data.style,
				picture: msg.data.payload.data.snapShotUrl,
				"content_available":"true"
		    },
		    data: {
		    	title: msg.data.title,
		    	message: msg.data.message,
		    	sound: msg.data.soundname,
		    	additionalData : JSON.stringify(Data),
		    	image : msg.data.image,
		    	notificationId : JSON.stringify(msg.data.notId),
		    	"content_available":"true"
		    }
			// notification: {
			// 	title: msg.data.title,
			// 	body: msg.data.message,
			// 	sound: "default",
			// 	//image: "http://gizmosmart.io/iot/1.3/public/uploadImage/2018050316101422.jpg",
			// 	style: msg.data.style,
			// 	picture: msg.data.picture,
			// 	//main_picture : "https://www.gettyimages.ie/gi-resources/images/Homepage/Hero/UK/CMS_Creative_164657191_Kingfisher.jpg",
			// 	"summeryText": msg.data.summaryText
			// }
		};
	}else{
		var message = {
			notification: {
				title : msg.data.title,
				body : msg.data.message,
				sound: msg.data.soundname,
				//icon: "notification_big",
				additionalData : JSON.stringify(Data),
				icon: msg.data.image,
				//"mutable-content": "1",
				"content_available": "true"
			},
		    data: {
		    	title : msg.data.title,
				text : msg.data.message,
				//body: msg.data.message,
				icon : msg.data.image,
				additionalData : JSON.stringify(Data),
				sound: msg.data.soundname,
				image: msg.data.image,
				//"mutable-content": "1",
				notificationId : JSON.stringify(msg.data.notId),
				"content_available": "true"
		    }
		};
	}

	var options = {
		"content_available" : true,
		"mutable_content" : true
		//"mutable-content": "1",
		//"content-available" : "1",
		
		//priority: "high"
	};
	//console.log(JSON.stringify(options));

	console.log(JSON.stringify(message) + "\n\n");

	//for(var i = 0; i<registration_id.length; i++){
	//	console.log(registration_id[i]);
		admin.messaging().sendToDevice(registration_id, message, options)
	    .then((response) => {
	      // Response is a message ID string.
	      console.log('Successfully sent message:', JSON.stringify(response));
	    })
	    .catch((error) => {
	      console.log('Error sending message:', JSON.stringify(error));
	    });
	//  var notif = {
	//  	notification: {
	// 		title : msg.data.title,
	// 		body : msg.data.message,
	// 		sound: msg.data.soundname,
	// 		//icon: "notification_big",
	// 		icon: msg.data.image,
	// 		"content-available": "true"
	// 	}
	//  }
	//  console.log(notif);
	// admin.messaging().sendToDevice(registration_id, notif)
 //    .then((response) => {
 //      // Response is a message ID string.
 //      console.log('Successfully sent message:', response);
 //    })
 //    .catch((error) => {
 //      console.log('Error sending message:', error);
 //    });

	//}
});
