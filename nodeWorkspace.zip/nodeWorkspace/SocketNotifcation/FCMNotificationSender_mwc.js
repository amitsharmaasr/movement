var d;
var time;

const admin = require('firebase-admin');
const serviceAccount = require('./serverPrivateKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://gizmolife-cloud-android.firebaseio.com/'

});

var redis = require('redis');
var redisClient = redis.createClient('6379', '172.26.4.161');

redisClient.subscribe('FCMNotifications_mwc');
console.log("FCM key has been subscribed");

redisClient.on('message', function(channel, message) {
	d = new Date();
	//time = d.getTime();
	console.log(d + ": New message in queue "+ message + "\n\n");
	var msg = JSON.parse(message);
	registration_id = msg.registration_ids;
	delete msg.registration_ids;
	//console.log(msg.data);

	var Data = {
		payload : msg.data.payload,
		priority : msg.data.priority
	}
	//hidden notification
	if(msg.data.title == "" || msg.data.message == ""){
		if(msg.data.hasOwnProperty('image') && msg.data.hasOwnProperty('notId')){
			var message = {
			    data: {
			    	title : msg.data.title,
			    	message : msg.data.message,
			    	id: JSON.stringify(msg.data.notId),
					additionalData : JSON.stringify(Data),
					sound: msg.data.soundname,
					image : msg.data.image,
					notificationId : JSON.stringify(msg.data.notId)
				}
			};
		}else{
			var message = {
			    data: {
			    	title : msg.data.title,
			    	message : msg.data.message,
					additionalData : JSON.stringify(Data),
					sound: msg.data.soundname
				}
			};
		}
	}
	//In case of Camera Rule
	else if(msg.data.hasOwnProperty('picture')){
		var message = {
			data: {
		    	title : msg.data.title,
				text : msg.data.message,
				icon : msg.data.image,
				id: JSON.stringify(msg.data.notId),
				additionalData : JSON.stringify(Data),
				sound: msg.data.soundname,
				image: msg.data.image,
				notificationId : JSON.stringify(msg.data.notId),
				style: msg.data.style,
				picture: msg.data.payload.data.snapShotUrl,
				"content-available":"true"
		    }
			// notification: {
			// 	title: msg.data.title,
			// 	body: msg.data.message,
			// 	sound: "default",
			// 	//image: "http://gizmosmart.io/iot/1.3/public/uploadImage/2018050316101422.jpg",
			// 	style: msg.data.style,
			// 	picture: msg.data.picture,
			// 	//main_picture : "https://www.gettyimages.ie/gi-resources/images/Homepage/Hero/UK/CMS_Creative_164657191_Kingfisher.jpg",
			// 	"summeryText": msg.data.summaryText
			// }
		};
	}else{
		var message = {
			// notification: {
			// 	title : msg.data.title,
			// 	body : msg.data.message,
			// 	sound: msg.data.soundname,
			// 	//icon: "notification_big",
			// 	icon: msg.data.image,
			// 	"content-available": "true"
			// },
		    data: {
		    	title : msg.data.title,
				text : msg.data.message,
				icon : msg.data.image,
				id: JSON.stringify(msg.data.notId),
				additionalData : JSON.stringify(Data),
				sound: msg.data.soundname,
				image: msg.data.image,
				notificationId : JSON.stringify(msg.data.notId),
				"content-available":"true"
		    }
		    // "image-url":
		};
	}

	var options = {
		contentAvailable : true
	};
	//console.log(JSON.stringify(options));

	console.log(JSON.stringify(message) + "\n\n");

	//for(var i = 0; i<registration_id.length; i++){
	//	console.log(registration_id[i]);
		admin.messaging().sendToDevice(registration_id, message, options)
	    .then((response) => {
	      // Response is a message ID string.
	      console.log('Successfully sent message:', JSON.stringify(response));
	      console.log("\n");
	    })
	    .catch((error) => {
	      console.log('Error sending message:', JSON.stringify(error) );
	      console.log("\n");
	    });
	//  var notif = {
	//  	notification: {
	// 		title : msg.data.title,
	// 		body : msg.data.message,
	// 		sound: msg.data.soundname,
	// 		//icon: "notification_big",
	// 		icon: msg.data.image,
	// 		"content-available": "true"
	// 	}
	//  }
	//  console.log(notif);
	// admin.messaging().sendToDevice(registration_id, notif)
 //    .then((response) => {
 //      // Response is a message ID string.
 //      console.log('Successfully sent message:', response);
 //    })
 //    .catch((error) => {
 //      console.log('Error sending message:', error);
 //    });

	//}
});
