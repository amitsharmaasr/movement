var fs = require('fs');
var https = require('https');
var join = require('path').join;
var express = require('express');
var app = express();
var redis = require('redis');

var options = {
 // key: fs.readFileSync(join(__dirname, '/1.key')),
 // cert: fs.readFileSync(join(__dirname, '/1.crt')),
 //ca: fs.readFileSync(join(__dirname, '/1.ca'))
};

var serverPort = 9000;

var server = https.createServer(options, app);
var io = require('socket.io')(server);

server.listen(serverPort, '0.0.0.0', function() {
  console.log('server up and running at %s port', serverPort);
  console.log('server listening to %j', server.address());
});


io.on('connection', function(socket) {
  console.log("new client connected");

  var redisClient = redis.createClient();
  var deviceLearning = redis.createClient();
  var hubStatusChange = redis.createClient();
  var group = redis.createClient();
  redisClient.subscribe('message');
  deviceLearning.subscribe('deviceLearnLive');
  hubStatusChange.subscribe('statusInfo');
  group.subscribe('GroupLive');
  console.log("new");

  redisClient.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });
  
  deviceLearning.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });
  
  hubStatusChange.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });

  group.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });

  socket.on('disconnect', function() {
    redisClient.quit();
  });
});

