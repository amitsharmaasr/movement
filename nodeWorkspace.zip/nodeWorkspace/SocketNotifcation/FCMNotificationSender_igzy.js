const admin = require('firebase-admin');
const serviceAccount = require('./serverPrivateKeyIgzy.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://igzy-1556023830939.firebaseio.com"

});

var redis = require('redis');
var redisClient = redis.createClient('6379', '172.26.4.161');

redisClient.subscribe('FCMNotifications_igzy');
console.log("FCM key has been subscribed");

redisClient.on('message', function(channel, message) {
	console.log("mew message in queue "+ message + "channel" + "\n\n");
	var msg = JSON.parse(message);
	registration_id = msg.registration_ids;
	delete msg.registration_ids;
	//console.log("message data is " + msg.data);

	var Data = {
		payload : msg.data.payload,
		priority : msg.data.priority
	}
	if(msg.data.title == "" || msg.data.message == ""){
		if(msg.data.hasOwnProperty('image') && msg.data.hasOwnProperty('notId')){
			var message = {
			    data: {
			    	title : msg.data.title,
					additionalData : JSON.stringify(Data),
					sound: msg.data.soundname,
					image : msg.data.image,
					"notificationId" : JSON.stringify(msg.data.notId)
				}
			};
		}else{
			var message = {
			    data: {
			    	title : msg.data.title,
					additionalData : JSON.stringify(Data),
					sound: msg.data.soundname
				}
			};
		}
	}else{
	     if(msg.data.notId == undefined) {
		notificationId = "";
	     }else {
		notificationId = JSON.stringify(msg.data.notId);
	     }
		var message = {
			notification: {
				title : msg.data.title,
				body : msg.data.message,
				sound: msg.data.soundname,
				//icon: "notification_big",
				icon: msg.data.image,
				"content-available": "true"
			},
		    data: {
		    	title : msg.data.title,
				message : msg.data.message,
				additionalData : JSON.stringify(Data),
				sound: msg.data.soundname,
				image: msg.data.image,
				"notificationId" : notificationId,
				"content-available":"true"
		    }
		    // "image-url":
		};
	}

	var options = {
		contentAvailable : true
	};
	console.log(JSON.stringify(options));

	console.log(JSON.stringify(message));
	console.log(JSON.stringify(msg.data.notId));

	//for(var i = 0; i<registration_id.length; i++){
	//	console.log(registration_id[i]);
		admin.messaging().sendToDevice(registration_id, message, options)
	    .then((response) => {
	      // Response is a message ID string.
	      console.log('Successfully sent message:', response);
	    })
	    .catch((error) => {
	      console.log('Error sending message:', error);
	    });
	//}
});

