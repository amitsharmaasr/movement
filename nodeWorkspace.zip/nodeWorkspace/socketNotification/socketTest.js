var fs = require('fs');
var https = require('http');
var join = require('path').join;
var express = require('express');
var app = express();
var redis = require('redis');
const CONNECTED_USERS_KEY = "connected_users";
var redis_client = redis.createClient(6379, '172.26.4.161');

var options = {
  key: fs.readFileSync('/home/devadmin/nodeWorkspace/SocketNotifcation/1.key'),
  cert: fs.readFileSync('/home/devadmin/nodeWorkspace/SocketNotifcation/1.crt')
//  csr: fs.readFileSync('/home/dev/cert/socket.csr ')
};
var serverPort = 9000;

var server = https.createServer(options, app);
var io = require('socket.io')(server);

server.listen(serverPort, function() {
  console.log('server up and running at %s port', serverPort);
  console.log('server listening to %j', server.address());
});

io.on('connection', function(socket) {
  console.log("new client connected");

  var redisClient = redis.createClient(6379, '172.26.4.161');
  var deviceLearning = redis.createClient(6379, '172.26.4.161');
  var hubStatusChange = redis.createClient(6379, '172.26.4.161');
  var group = redis.createClient(6379, '172.26.4.161');
  redisClient.subscribe('message');
  deviceLearning.subscribe('deviceLearnLive');
  hubStatusChange.subscribe('statusInfo');
  group.subscribe('GroupLive');
  console.log("new");
 
  redisClient.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });
  
  deviceLearning.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });
  
  hubStatusChange.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });

  group.on('message', function(channel, message) {
    console.log("new message in queue "+ message + "channel");
    socket.emit(channel, message);
  });

  socket.on('disconnect', function() {
    redisClient.quit();
  });
});
