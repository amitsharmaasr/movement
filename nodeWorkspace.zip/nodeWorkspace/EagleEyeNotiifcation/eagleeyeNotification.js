    var WebSocketClient = require('websocket').client;
    var redis = require('redis');
    const shell = require('shelljs');

    var redisClient = redis.createClient('6379', '172.26.4.161');
    redisClient.on('connect', function () {
        console.log('Redis connected');
    });

    // WebSocket Connections
    const connections = [];

    // List of users whose data is not required
    //'00024729',
    //   '00027063',
    //  '00024241',
    // '00025534',
        //'00025853'

    const ignoreClients = [
   '000171360',
'00017184',
'00017137',
//'00026029',
'00024459',
'00027063',
'00027510',
'00028210',
'00028194',
'00028196',
'00025534',
'00028172',
'00025192',
'00026260',
'00024241',
'00025853'
]
    // connect multiple client

    // ****** Setup Phase ********
    // End Client info i.e. users of the app

    const clients = [];
    let eagleeyecamera = [];
    let count = true;

    // get camera list
    redisClient.get('EagleEyeNetworksSCamera', function (err, networkscamera) {

        eagleeyecamera = JSON.parse(networkscamera);
       
        // console.log("camera list ... firsr"+ eagleeyecamera)
    });

    redisClient.get('EagleEyeNetworksSession', function (err, networks) {
        const eagleEyeNetworks = JSON.parse(networks);
	if(Array.isArray(eagleEyeNetworks)){
        console.log("data "+ JSON.stringify(eagleEyeNetworks));		
        eagleEyeNetworks.forEach(function (element) {

            // clients.push({ 'account': element['account_id'], 'url': 'wss://gizmosmart.eagleeyenetworks.com/api/v2/Device/' + element["account_id"] + '/Events?A=' + element["session"], 'cameraList': element["camera_list"] });

            // clients.push({ 'account': element['account_id'], 'url': 'wss://gizmosmart.eagleeyenetworks.com/api/v2/Device/' + element["account_id"] + '/Events?A=' + element["session"], 'cameraList': getCameraList(element["account_id"]).then((result) => { console.log(JSON.stringify(result['camera_list'])); })});


            if(eagleeyecamera[element["account_id"]] != undefined && eagleeyecamera[element["account_id"]]['camera_list'] != undefined)
            {
                clients.push({ 'account': element['account_id'], 'url': 'wss://gizmosmart.eagleeyenetworks.com/api/v2/Device/' + element["account_id"] + '/Events?A=' + element["session"], 'cameraList': eagleeyecamera[element["account_id"]]['camera_list'] });
            }
            else{
                clients.push({ 'account': element['account_id'], 'url': 'wss://gizmosmart.eagleeyenetworks.com/api/v2/Device/' + element["account_id"] + '/Events?A=' + element["session"] });
            }
          

        });
        
        clients.filter(c => ignoreClients.indexOf(c.account) === -1).forEach(function (client) {
            const connection = new WebSocketClient();
            connections.push(connection);
            connection.on('connectFailed', function(error) {
            if(count){	
                console.log("***** Re generate auth session of account *******");
                
                shell.exec("bash /var/www/html/nodejs/script.sh",{silent:true,async:false}).output;
                // shell.exec('cd /var/www/html/nodejs/script.sh');
                
                connectToEagleEye(connection, client);
                console.log("***** generate session successfully *******");
		shell.exec('pm2 restart 6');
                count = false;
                // setupSocketConnectionForEagelEye(connection, client);		
            } 
            });
            setupSocketConnectionForEagelEye(connection, client);
        });
    }});




    // ****** Setup Phase Ends ********

    // get camera list from redis database
    // let getCameraList = (account_id) => {
    //     return new Promise((resolve,reject) => {
    //         redisClient.get('EagleEyeNetworksSCamera', function (err, networks) {
    //             let  eagleEyeCamera = JSON.parse(networks);
    //             // console.log("camera list ..."+ JSON.stringify(eagleEyeCamera));
    //             if(err)
    //             {
    //                 reject(err);
    //             }
    //             else{
    //                 resolve(eagleEyeCamera[account_id]);
    //             }
    //             // if(eagleEyeCamera.hasOwnProperty('camera_list'))
    //             // {
    //             //     resolve(account_id);
    //             // }
                
    //         });
    //     });
    // }

    
    

    /**
     * Setup socket connection for a client(user)   
     * @param {*} connection 
     * @param {*} client 
     */
    function setupSocketConnectionForEagelEye(connection, client) {
        	
        connectToEagleEye(connection, client);
        connection.on('connect', function (_connection) {
            console.log('WebSocket Client ' + client.account + ' Connected');
            _connection.on('error', function (error) {
                onRedisConnectionError(client, error);
            });
            _connection.on('close', function (reasonCode, description) {
                onRedisConnectionClose(reasonCode, description, connection, client);
            });
            _connection.on('message', function (message) {
                onRedisMessage(message, client.account);
            });
            sendData(client, _connection);
        });
    }

    function connectToEagleEye(connection, client) {
        count = true;
        console.log("Reconnecting... " + client.account);
        connection.connect(client.url);
    }

    function sendData(client, connection) {
        if (connection.connected) {
            //var header = '{"cameras":{';
            var header = '';
            if (client.hasOwnProperty('cameraList')) {
                client.cameraList.forEach(function (camera) {

                    if (camera != 'null') {
                        header = '{"cameras":{"' + camera + '"' + ':{"resource":["event","status","pre"],"event":["CONN", "CZTS"]}}}';
                    }
                
                    //var n = header.lastIndexOf(",");
                    //header = header.substr(0, n) + '}}';
                    console.log("Camera JSON in Client " + client.account);
                console.log("Camera JSON client  " + header);
                    if (header != '}}') {
                        connection.send(header);
                    }
    
                    console.log("connection success client " + client.account);
                });
            }
            
        }
    }

    function onRedisMessage(message, account) {
        console.log("Message Received in Client" + account);
        // processEvent(message);
        if (message.type === 'utf8') {
            console.log("Received: '" + message.utf8Data + "'");
            var eventData = JSON.parse(message.utf8Data);
            var data = JSON.stringify(eventData.data);
        
        //console.log('data length NO '+ data.length);
            if (data.length > '2') {

        var camera_id = data.substring(2, 10);
            //camera = Object.create(null);
        camera = eventData.data[camera_id];
               
        if (camera.hasOwnProperty('event')) {
        
            //if (Object.prototype.hasOwnProperty.call(camera,'event')) {

                if (camera.event.hasOwnProperty('CONN')) {
                    conn = camera.event['CONN'];
                    timeStamp = conn.timestamp;
                    cameraId = conn.cameraid;
                    var jsonconn = {
                        timestamp: timeStamp,
                        camera_id: cameraId,
                        status: 'AVAILABLE'
                    };
                    //var redisClient = redis.createClient('6379', '192.168.10.20');
                    redisClient.rpush('EagleEyeEvent', [JSON.stringify(jsonconn)]);
                    console.log("*********************Camera online Event Added*********************");
                }
                if (camera.event.hasOwnProperty('CZTS')) {
                    czts = camera.event['CZTS'];
                    timeStamp = czts.timestamp;
                    cameraId = czts.cameraid;
                    var jsonczts = {
                        timestamp: timeStamp,
                        camera_id: cameraId,
                        status: 'UNAVAILABLE'
                    };
                    //var redisClient = redis.createClient('6379', '192.168.10.20');
                    redisClient.rpush('EagleEyeEvent', [JSON.stringify(jsonczts)]);
                    console.log("*********************Camera offline Event Added*********************");
                }
            } else {
            console.log(camera_id);
        }

        } //Temp
        }
    }

    function onRedisConnectionError(client, error) {
        console.error("Connection Error client " + client.account + ": " + error.toString());
        //shell.exec('./script.sh');
        connectToEagleEye(connection, client);
    }

    function onRedisConnectionClose(reasonCode, description, connection, client) {
        console.error('Peer ' + connection.remoteAddress + 'reason code is :' + reasonCode + ' descriotion:' + description + ' disconnected at : ', new Date());
        console.error('********************************** Connection Closed client ' + client.account + '**********************************');
        connectToEagleEye(connection, client);
    }

