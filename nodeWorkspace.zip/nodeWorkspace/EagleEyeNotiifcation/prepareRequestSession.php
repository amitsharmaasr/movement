<?php

try{
	$redis = new Redis();
	$redis->connect('172.26.4.161','6379');
}catch(Exception $e){
	die($e->getMessage()."\n");
}

catch(Exception $e){
  echo "Database error occured";
}


// send mail
// $to = "santosh.kumar1@kochartech.com";
// $subject = "Re generate session";
// $txt = "Re generate session !";
// $headers = "From: puneet.mehra@kochartech.com" . "\r\n";

// mail($to,$subject,$txt,$headers);

//die;
/**
** Get the master account token
**/
echo "****************getMasterAccountToken****************\n";
$auth_key = getMasterAccountToken();

/**
** Get the list of Accounts Associated with master Account
**/
echo "****************getAccountList****************\n";
$account_list = getAccountList($auth_key);
// $account_list = array(0 => array("00024729","Pepperfry Studio"));

if(count($account_list)>0){
	$request = array();
	$j = 0;
	foreach ($account_list as $account) {	
		/** 
		** Get Master Account Token
		**/
		$authkey = getMasterAccountToken();
		
		/**
		** Switch into each user account one by one with individual session token
		**/
		$account_no = $account[0];
		$account_name = $account[1];

		// echo "**************** Processing Account ". $j ." ****************\n\n";
		// echo "**************** Account Id: ".$account_no." ****************\n\n";
		
		$switch_account_cmd = "curl -X POST https://login.eagleeyenetworks.com/g/aaa/switch_account -d \"account_id=".$account_no."\" -H \"Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:\" --cookie \"auth_key=".$authkey."\" -H \"Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:\" -v";
		
		shell_exec($switch_account_cmd);
		
		// echo "****************getCamerasList****************\n";
		// $camera_list = getCamerasList($authkey);
		// $camList = array();
		 
		// foreach ($camera_list as $cam_list) {
			
		// 	if($cam_list[3] == 'camera' && $cam_list[1] != null)
		// 	{
		// 		$camera_id = $cam_list[1];
		// 		//$camera_name = $cam_list[2];
		// 		echo "****************initializePoll****************\n";
		// 		//initializePoll($authkey, $camera_id);
		// 		//$temp = prepareJSON($camera_id);
		// 		array_push($camList, $camera_id);
		// 		var_dump($camList);
		// 	}	
			
			
		// }
		// if(count($camList)>0){
		// 	$camJson = array("account_id"=>$account_no, "account_name"=>$account_name, "session"=>$authkey, "camera_list"=>$camList);
		// 	array_push($request, $camJson);
		// }
		// var_dump($request);
		
		$camJson = array("account_id"=>$account_no, "account_name"=>$account_name, "session"=>$authkey);
		array_push($request, $camJson);
		
	}
	if(count($request)>0){
		$redis->set("EagleEyeNetworksSession", json_encode($request));
	}
	echo "Final request Prepared";
	var_dump(json_encode($request));
	// pg_close($db);
}


function prepareJSON($camera_id){
	$cam = array("id"=>$camera_id);
	//array($camera_id=>array("resource"=>array("event","status","pre"),"event"=>array("RCON","RCOF")));
	var_dump($cam);
	return $cam;
}

function insertDataintoDB($camera_id, $camera_name, $db){
	$status = true;
	$is_online = true;
	$sql = "insert into camera_notifications_temp(camera_id, camera_name, status, is_online) values('".$camera_id."', '".$camera_name."', true, true)";
	// $param = array('user_id'=>114, 'user_name'=>'abc');
	// $sql = "select * from users where ".$param;
	$ret = pg_query($db, $sql);
	if(!$ret){
		echo pg_last_error($db);
	}
	

}

function initializePoll($auth_key, $camera_id){
	$initPollCmd = "curl -X POST https://login.eagleeyenetworks.com/poll -d '{\"cameras\":{\"".$camera_id."\":{\"resource\":[\"event\",\"status\"],\"event\":[\"COFF\", \"RCON\", \"RCOF\",\"CONN\", \"CBWS\", \"CZTS\", \"CPRG\", \"AEDC\", \"AEDD\"]}}}' -H 'Content-Type: application/json' -H \"Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:\" --cookie \"auth_key=".$auth_key."\" -v";
	// $initPollCmd = "curl -X POST https://login.eagleeyenetworks.com/poll -d '{\"cameras\":{\"".$camera_id."\":{\"resource\":[\"event\",\"status\"],\"event\":[\"RCON\",\"RCOF\",\"AEDC\",\"AEDD\"]}}}' -H 'Content-Type: application/json' -H \"Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:\" --cookie \"auth_key=".$auth_key."\" -v";
	shell_exec($initPollCmd);
}

function getCamerasList($auth_key){
	$camListCmd = "curl --request GET https://login.eagleeyenetworks.com/g/device/list -H \"Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:\" --cookie \"auth_key=".$auth_key."\"";
	$resp = shell_exec($camListCmd);
	$camera_list = json_decode($resp);
	return $camera_list;
}

/**
** Returns the list of Accounts Associated with master Account
**/
function getAccountList($auth_key){
	$accountListCmd = "curl -X GET https://login.eagleeyenetworks.com/g/account/list -H \"Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:\" --cookie \"auth_key=".$auth_key."\" -G";
	$resp = shell_exec($accountListCmd);
	if($resp){
		$account_list = json_decode($resp, true);
		//var_dump($account_list);
		return $account_list;
	}else{
		return array();
	}
}

/** 
** generate session token for each account
**/
function getMasterAccountToken(){
	$cmd = "curl -X POST https://login.eagleeyenetworks.com/g/aaa/authenticate -d '{\"username\": \"gaurav.gupta@kochartech.com\", \"password\": \"Kochar@5678\"}' -H \"content-type: application/json\" -H \"Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:\"";
	$res = shell_exec($cmd);
	$token = json_decode($res,true);
	$cmd = 'curl -D - -X POST https://login.eagleeyenetworks.com/g/aaa/authorize -d \'{"token": "'.$token['token'].'"}\' -H "content-type: application/json" -H "Authentication: 95df296a-f5ef-11e7-aa19-02420a802d05:"';
	$auth = shell_exec($cmd);
	$authkey = substr($auth, stripos($auth, 'auth_key=')+9,37);
	var_dump($authkey);
	return $authkey;
}


?>
